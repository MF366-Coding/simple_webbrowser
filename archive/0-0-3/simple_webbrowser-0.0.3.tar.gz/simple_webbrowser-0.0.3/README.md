# simple_webbrowser
`simple_webbrowser` is a module that makes `webbrowser` module way more simple to work with.

# License
This module is licensed under the MIT License.

# PyPI
This module is not available on PyPI.

Instead, it's here, on GitHub... 